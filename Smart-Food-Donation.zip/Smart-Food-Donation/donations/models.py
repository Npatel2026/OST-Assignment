from django.db import models
from django.contrib.auth.models import User


class FoodDonation(models.Model):
    food_name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField()
    location = models.CharField(max_length=200)
    expiry_date = models.DateField()
    description = models.TextField(blank=True)
    donor = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.food_name