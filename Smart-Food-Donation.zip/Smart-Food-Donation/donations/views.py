from datetime import date

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django import forms

from .models import FoodDonation


# Home Page
def home(request):
    return render(request, 'donations/home.html')


# Registration Form
class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta(UserCreationForm.Meta):
        fields = ['username', 'email']


# User Registration
def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)

        if form.is_valid():
            user = form.save()
            login(request, user)

            messages.success(
                request,
                'Your account was created successfully!'
            )

            return redirect('dashboard')
    else:
        form = RegisterForm()

    return render(
        request,
        'donations/register.html',
        {'form': form}
    )


# User Login
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:
            login(request, user)
            return redirect('dashboard')

        messages.error(request, 'Invalid username or password.')

    return render(request, 'donations/login.html')


# Dashboard
@login_required
def dashboard(request):
    return render(request, 'donations/dashboard.html')


# User Logout
def user_logout(request):
    logout(request)
    return redirect('home')


# Add Food Donation with Validation
@login_required
def add_donation(request):
    if request.method == 'POST':

        print("ADD DONATION FUNCTION EXECUTED")

        food_name = request.POST.get('food_name', '').strip()
        quantity = request.POST.get('quantity', '')
        location = request.POST.get('location', '').strip()
        expiry_date = request.POST.get('expiry_date', '')
        description = request.POST.get('description', '').strip()

        print("Submitted expiry date:", expiry_date)
        print("Today's date:", date.today())

        if not food_name or not quantity or not location or not expiry_date:
            messages.error(request, 'Please fill in all required fields.')
            return render(request, 'donations/add_donation.html')

        try:
            expiry_date = date.fromisoformat(expiry_date)
        except (ValueError, TypeError):
            messages.error(request, 'Invalid expiry date.')
            return render(request, 'donations/add_donation.html')

        if expiry_date < date.today():
            messages.error(
                request,
                'EXPIRED FOOD REJECTED! Select today or a future date.'
            )
            return render(request, 'donations/add_donation.html')

        try:
            quantity = int(quantity)
            if quantity <= 0:
                raise ValueError
        except (ValueError, TypeError):
            messages.error(request, 'Quantity must be greater than zero.')
            return render(request, 'donations/add_donation.html')

        FoodDonation.objects.create(
            food_name=food_name,
            quantity=quantity,
            location=location,
            expiry_date=expiry_date,
            description=description,
            donor=request.user
        )

        messages.success(request, 'Food donation added successfully!')
        return redirect('view_donations')

    return render(request, 'donations/add_donation.html')
# View All Food Donations
@login_required
def view_donations(request):
    donations = FoodDonation.objects.all().order_by('-created_at')

    return render(
        request,
        'donations/view_donations.html',
        {'donations': donations}
    )


# Update Food Donation
@login_required
def update_donation(request, donation_id):
    donation = get_object_or_404(
        FoodDonation,
        id=donation_id,
        donor=request.user
    )

    if request.method == 'POST':
        food_name = request.POST.get('food_name', '').strip()
        quantity = request.POST.get('quantity', '')
        location = request.POST.get('location', '').strip()
        expiry_date = request.POST.get('expiry_date', '')
        description = request.POST.get('description', '').strip()

        if not food_name or not quantity or not location or not expiry_date:
            messages.error(
                request,
                'Please fill in all required fields.'
            )

            return render(
                request,
                'donations/update_donation.html',
                {'donation': donation}
            )

        try:
            expiry_date = date.fromisoformat(expiry_date)
        except ValueError:
            messages.error(
                request,
                'Please enter a valid expiry date.'
            )

            return render(
                request,
                'donations/update_donation.html',
                {'donation': donation}
            )

        if expiry_date < date.today():
            messages.error(
                request,
                'Expired food cannot be listed. '
                'Please select today or a future date.'
            )

            return render(
                request,
                'donations/update_donation.html',
                {'donation': donation}
            )

        try:
            quantity = int(quantity)

            if quantity <= 0:
                raise ValueError

        except ValueError:
            messages.error(
                request,
                'Quantity must be a positive whole number.'
            )

            return render(
                request,
                'donations/update_donation.html',
                {'donation': donation}
            )

        donation.food_name = food_name
        donation.quantity = quantity
        donation.location = location
        donation.expiry_date = expiry_date
        donation.description = description

        donation.save()

        messages.success(
            request,
            'Donation updated successfully!'
        )

        return redirect('view_donations')

    return render(
        request,
        'donations/update_donation.html',
        {'donation': donation}
    )


# Delete Food Donation
@login_required
def delete_donation(request, donation_id):
    donation = get_object_or_404(
        FoodDonation,
        id=donation_id,
        donor=request.user
    )

    if request.method == 'POST':
        donation.delete()

        messages.success(
            request,
            'Donation deleted successfully!'
        )

    return redirect('view_donations')